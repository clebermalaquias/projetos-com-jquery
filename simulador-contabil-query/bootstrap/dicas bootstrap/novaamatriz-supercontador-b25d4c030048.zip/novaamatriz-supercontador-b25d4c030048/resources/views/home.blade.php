@extends('layouts.app')

@section('content')
<header>
<div class="container">
</div>
</header>
@endsection
